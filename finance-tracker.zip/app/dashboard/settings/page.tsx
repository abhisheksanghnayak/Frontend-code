"use client"

import { useEffect, useState } from "react"
import { useRouter } from "next/navigation"
import DashboardLayout from "@/components/dashboard-layout"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Switch } from "@/components/ui/switch"
import { Label } from "@/components/ui/label"
import { BellIcon, DownloadIcon, KeyIcon, ShieldIcon, TrashIcon } from "lucide-react"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import { Input } from "@/components/ui/input"

export default function SettingsPage() {
  const [user, setUser] = useState(null)
  const [settings, setSettings] = useState({
    emailNotifications: true,
    darkMode: false,
    autoExport: false,
    twoFactorAuth: false,
  })
  const [isDeleteDialogOpen, setIsDeleteDialogOpen] = useState(false)
  const [isPasswordDialogOpen, setIsPasswordDialogOpen] = useState(false)
  const [passwordData, setPasswordData] = useState({
    currentPassword: "",
    newPassword: "",
    confirmPassword: "",
  })
  const [message, setMessage] = useState({ text: "", type: "" })
  const router = useRouter()

  useEffect(() => {
    // Check if user is logged in
    const currentUser = localStorage.getItem("currentUser")
    if (!currentUser) {
      router.push("/login")
      return
    }

    const userData = JSON.parse(currentUser)
    setUser(userData)

    // Load settings (or use defaults)
    const userSettings = JSON.parse(localStorage.getItem(`settings_${userData.id}`) || JSON.stringify(settings))
    setSettings(userSettings)
  }, [router])

  const handleSettingChange = (setting) => {
    const updatedSettings = {
      ...settings,
      [setting]: !settings[setting],
    }

    setSettings(updatedSettings)
    localStorage.setItem(`settings_${user.id}`, JSON.stringify(updatedSettings))

    setMessage({
      text: "Settings updated successfully",
      type: "success",
    })

    // Clear message after 3 seconds
    setTimeout(() => {
      setMessage({ text: "", type: "" })
    }, 3000)
  }

  const handlePasswordChange = (e) => {
    const { name, value } = e.target
    setPasswordData((prev) => ({ ...prev, [name]: value }))
  }

  const handlePasswordSubmit = (e) => {
    e.preventDefault()
    setMessage({ text: "", type: "" })

    // Validation
    if (!passwordData.currentPassword || !passwordData.newPassword || !passwordData.confirmPassword) {
      setMessage({ text: "All fields are required", type: "error" })
      return
    }

    if (passwordData.currentPassword !== user.password) {
      setMessage({ text: "Current password is incorrect", type: "error" })
      return
    }

    if (passwordData.newPassword !== passwordData.confirmPassword) {
      setMessage({ text: "New passwords do not match", type: "error" })
      return
    }

    if (passwordData.newPassword.length < 6) {
      setMessage({ text: "Password must be at least 6 characters", type: "error" })
      return
    }

    // Update password
    const updatedUser = {
      ...user,
      password: passwordData.newPassword,
    }

    // Update in localStorage
    localStorage.setItem("currentUser", JSON.stringify(updatedUser))

    // Also update in users array
    const users = JSON.parse(localStorage.getItem("users") || "[]")
    const updatedUsers = users.map((u) => (u.id === user.id ? updatedUser : u))
    localStorage.setItem("users", JSON.stringify(updatedUsers))

    setUser(updatedUser)
    setMessage({ text: "Password updated successfully", type: "success" })
    setIsPasswordDialogOpen(false)

    // Reset form
    setPasswordData({
      currentPassword: "",
      newPassword: "",
      confirmPassword: "",
    })
  }

  const handleDeleteAccount = () => {
    // Remove user from users array
    const users = JSON.parse(localStorage.getItem("users") || "[]")
    const updatedUsers = users.filter((u) => u.id !== user.id)
    localStorage.setItem("users", JSON.stringify(updatedUsers))

    // Remove user data
    localStorage.removeItem(`transactions_${user.id}`)
    localStorage.removeItem(`budgets_${user.id}`)
    localStorage.removeItem(`settings_${user.id}`)
    localStorage.removeItem("currentUser")

    // Redirect to login
    router.push("/login")
  }

  const handleExportData = () => {
    // Gather all user data
    const userData = {
      user: user,
      transactions: JSON.parse(localStorage.getItem(`transactions_${user.id}`) || "[]"),
      budgets: JSON.parse(localStorage.getItem(`budgets_${user.id}`) || "[]"),
      settings: settings,
    }

    // Convert to JSON string
    const dataStr = JSON.stringify(userData, null, 2)

    // Create a blob and download link
    const blob = new Blob([dataStr], { type: "application/json" })
    const url = URL.createObjectURL(blob)
    const a = document.createElement("a")
    a.href = url
    a.download = `fintrack_data_${user.id}.json`
    document.body.appendChild(a)
    a.click()

    // Cleanup
    document.body.removeChild(a)
    URL.revokeObjectURL(url)
  }

  if (!user) {
    return <div className="flex items-center justify-center min-h-screen">Loading...</div>
  }

  return (
    <DashboardLayout>
      <div className="flex items-center justify-between mb-6">
        <h1 className="text-3xl font-bold">Settings</h1>
      </div>

      {message.text && (
        <div
          className={`mb-6 p-3 rounded-md ${
            message.type === "error" ? "bg-red-100 text-red-800" : "bg-green-100 text-green-800"
          }`}
        >
          {message.text}
        </div>
      )}

      <div className="grid gap-6">
        <Card>
          <CardHeader>
            <CardTitle>Notifications</CardTitle>
            <CardDescription>Manage your notification preferences</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-4">
                <BellIcon className="h-5 w-5 text-muted-foreground" />
                <div>
                  <p className="text-sm font-medium">Email Notifications</p>
                  <p className="text-sm text-muted-foreground">Receive email updates about your account</p>
                </div>
              </div>
              <Switch
                checked={settings.emailNotifications}
                onCheckedChange={() => handleSettingChange("emailNotifications")}
              />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Appearance</CardTitle>
            <CardDescription>Customize your interface</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-4">
                <div className="h-5 w-5 text-muted-foreground">🌙</div>
                <div>
                  <p className="text-sm font-medium">Dark Mode</p>
                  <p className="text-sm text-muted-foreground">Switch between light and dark themes</p>
                </div>
              </div>
              <Switch checked={settings.darkMode} onCheckedChange={() => handleSettingChange("darkMode")} />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Data & Privacy</CardTitle>
            <CardDescription>Manage your data and privacy settings</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-4">
                <DownloadIcon className="h-5 w-5 text-muted-foreground" />
                <div>
                  <p className="text-sm font-medium">Auto Export</p>
                  <p className="text-sm text-muted-foreground">Automatically export your data monthly</p>
                </div>
              </div>
              <Switch checked={settings.autoExport} onCheckedChange={() => handleSettingChange("autoExport")} />
            </div>
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-4">
                <ShieldIcon className="h-5 w-5 text-muted-foreground" />
                <div>
                  <p className="text-sm font-medium">Two-Factor Authentication</p>
                  <p className="text-sm text-muted-foreground">Add an extra layer of security</p>
                </div>
              </div>
              <Switch checked={settings.twoFactorAuth} onCheckedChange={() => handleSettingChange("twoFactorAuth")} />
            </div>
            <div className="pt-4">
              <Button variant="outline" className="w-full" onClick={handleExportData}>
                <DownloadIcon className="mr-2 h-4 w-4" />
                Export All Data
              </Button>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Security</CardTitle>
            <CardDescription>Manage your account security</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <Button variant="outline" className="w-full" onClick={() => setIsPasswordDialogOpen(true)}>
              <KeyIcon className="mr-2 h-4 w-4" />
              Change Password
            </Button>
            <Button variant="destructive" className="w-full" onClick={() => setIsDeleteDialogOpen(true)}>
              <TrashIcon className="mr-2 h-4 w-4" />
              Delete Account
            </Button>
          </CardContent>
        </Card>
      </div>

      {/* Change Password Dialog */}
      <Dialog open={isPasswordDialogOpen} onOpenChange={setIsPasswordDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Change Password</DialogTitle>
            <DialogDescription>Enter your current password and a new password.</DialogDescription>
          </DialogHeader>
          <form onSubmit={handlePasswordSubmit}>
            {message.text && message.type === "error" && (
              <div className="text-sm font-medium text-red-500 mb-4">{message.text}</div>
            )}
            <div className="grid gap-4 py-4">
              <div className="grid gap-2">
                <Label htmlFor="currentPassword">Current Password</Label>
                <Input
                  id="currentPassword"
                  name="currentPassword"
                  type="password"
                  value={passwordData.currentPassword}
                  onChange={handlePasswordChange}
                  required
                />
              </div>
              <div className="grid gap-2">
                <Label htmlFor="newPassword">New Password</Label>
                <Input
                  id="newPassword"
                  name="newPassword"
                  type="password"
                  value={passwordData.newPassword}
                  onChange={handlePasswordChange}
                  required
                />
              </div>
              <div className="grid gap-2">
                <Label htmlFor="confirmPassword">Confirm New Password</Label>
                <Input
                  id="confirmPassword"
                  name="confirmPassword"
                  type="password"
                  value={passwordData.confirmPassword}
                  onChange={handlePasswordChange}
                  required
                />
              </div>
            </div>
            <DialogFooter>
              <Button type="submit">Save Changes</Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>

      {/* Delete Account Dialog */}
      <Dialog open={isDeleteDialogOpen} onOpenChange={setIsDeleteDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Delete Account</DialogTitle>
            <DialogDescription>
              Are you sure you want to delete your account? This action cannot be undone.
            </DialogDescription>
          </DialogHeader>
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsDeleteDialogOpen(false)}>
              Cancel
            </Button>
            <Button variant="destructive" onClick={handleDeleteAccount}>
              Delete Account
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </DashboardLayout>
  )
}
