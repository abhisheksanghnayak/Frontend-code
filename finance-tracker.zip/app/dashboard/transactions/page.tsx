"use client"

import { useEffect, useState } from "react"
import { useRouter } from "next/navigation"
import DashboardLayout from "@/components/dashboard-layout"
import TransactionList from "@/components/transaction-list"
import { Button } from "@/components/ui/button"
import { PlusIcon } from "lucide-react"
import AddTransactionDialog from "@/components/add-transaction-dialog"

export default function TransactionsPage() {
  const [user, setUser] = useState(null)
  const [transactions, setTransactions] = useState([])
  const [isAddTransactionOpen, setIsAddTransactionOpen] = useState(false)
  const router = useRouter()

  useEffect(() => {
    // Check if user is logged in
    const currentUser = localStorage.getItem("currentUser")
    if (!currentUser) {
      router.push("/login")
      return
    }

    const userData = JSON.parse(currentUser)
    setUser(userData)

    // Load transactions
    const userTransactions = JSON.parse(localStorage.getItem(`transactions_${userData.id}`) || "[]")
    setTransactions(userTransactions)
  }, [router])

  const handleAddTransaction = (newTransaction) => {
    const updatedTransactions = [
      ...transactions,
      {
        ...newTransaction,
        id: Date.now().toString(),
        date: new Date().toISOString(),
      },
    ]

    setTransactions(updatedTransactions)
    localStorage.setItem(`transactions_${user.id}`, JSON.stringify(updatedTransactions))
    setIsAddTransactionOpen(false)
  }

  if (!user) {
    return <div className="flex items-center justify-center min-h-screen">Loading...</div>
  }

  return (
    <DashboardLayout>
      <div className="flex items-center justify-between mb-6">
        <h1 className="text-3xl font-bold">Transactions</h1>
        <Button onClick={() => setIsAddTransactionOpen(true)} className="bg-green-600 hover:bg-green-700">
          <PlusIcon className="mr-2 h-4 w-4" /> Add Transaction
        </Button>
      </div>

      <TransactionList transactions={transactions} />

      <AddTransactionDialog
        open={isAddTransactionOpen}
        onOpenChange={setIsAddTransactionOpen}
        onAddTransaction={handleAddTransaction}
      />
    </DashboardLayout>
  )
}
