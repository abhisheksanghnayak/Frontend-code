"use client"

import { useEffect, useState } from "react"
import { useRouter } from "next/navigation"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { ArrowDownIcon, ArrowUpIcon, CalendarIcon, PlusIcon, WalletIcon } from "lucide-react"
import DashboardLayout from "@/components/dashboard-layout"
import TransactionList from "@/components/transaction-list"
import AddTransactionDialog from "@/components/add-transaction-dialog"
import { ExpenseChart, IncomeChart } from "@/components/finance-charts"
import BudgetSection from "@/components/budget-section"

export default function DashboardPage() {
  const [user, setUser] = useState(null)
  const [transactions, setTransactions] = useState([])
  const [isAddTransactionOpen, setIsAddTransactionOpen] = useState(false)
  const [stats, setStats] = useState({
    totalIncome: 0,
    totalExpenses: 0,
    balance: 0,
  })
  const router = useRouter()

  useEffect(() => {
    // Check if user is logged in
    const currentUser = localStorage.getItem("currentUser")
    if (!currentUser) {
      router.push("/login")
      return
    }

    const userData = JSON.parse(currentUser)
    setUser(userData)

    // Load transactions
    const userTransactions = JSON.parse(localStorage.getItem(`transactions_${userData.id}`) || "[]")
    setTransactions(userTransactions)

    // Calculate stats
    const income = userTransactions.filter((t) => t.type === "income").reduce((sum, t) => sum + t.amount, 0)

    const expenses = userTransactions.filter((t) => t.type === "expense").reduce((sum, t) => sum + t.amount, 0)

    setStats({
      totalIncome: income,
      totalExpenses: expenses,
      balance: income - expenses,
    })
  }, [router])

  const handleAddTransaction = (newTransaction) => {
    const updatedTransactions = [
      ...transactions,
      {
        ...newTransaction,
        id: Date.now().toString(),
        date: new Date().toISOString(),
      },
    ]

    setTransactions(updatedTransactions)
    localStorage.setItem(`transactions_${user.id}`, JSON.stringify(updatedTransactions))

    // Update stats
    const income = updatedTransactions.filter((t) => t.type === "income").reduce((sum, t) => sum + t.amount, 0)

    const expenses = updatedTransactions.filter((t) => t.type === "expense").reduce((sum, t) => sum + t.amount, 0)

    setStats({
      totalIncome: income,
      totalExpenses: expenses,
      balance: income - expenses,
    })

    setIsAddTransactionOpen(false)
  }

  if (!user) {
    return <div className="flex items-center justify-center min-h-screen">Loading...</div>
  }

  return (
    <DashboardLayout>
      <div className="flex items-center justify-between mb-6">
        <h1 className="text-3xl font-bold">Dashboard</h1>
        <Button onClick={() => setIsAddTransactionOpen(true)} className="bg-green-600 hover:bg-green-700">
          <PlusIcon className="mr-2 h-4 w-4" /> Add Transaction
        </Button>
      </div>

      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4 mb-6">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Balance</CardTitle>
            <WalletIcon className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">${stats.balance.toFixed(2)}</div>
            <p className="text-xs text-muted-foreground">Current balance</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Income</CardTitle>
            <ArrowUpIcon className="h-4 w-4 text-green-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-green-500">${stats.totalIncome.toFixed(2)}</div>
            <p className="text-xs text-muted-foreground">Total income</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Expenses</CardTitle>
            <ArrowDownIcon className="h-4 w-4 text-red-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-red-500">${stats.totalExpenses.toFixed(2)}</div>
            <p className="text-xs text-muted-foreground">Total expenses</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">This Month</CardTitle>
            <CalendarIcon className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">${(stats.totalIncome - stats.totalExpenses).toFixed(2)}</div>
            <p className="text-xs text-muted-foreground">Monthly savings</p>
          </CardContent>
        </Card>
      </div>

      <Tabs defaultValue="transactions" className="space-y-4">
        <TabsList>
          <TabsTrigger value="transactions">Transactions</TabsTrigger>
          <TabsTrigger value="analytics">Analytics</TabsTrigger>
          <TabsTrigger value="budgets">Budgets</TabsTrigger>
        </TabsList>
        <TabsContent value="transactions" className="space-y-4">
          <TransactionList transactions={transactions} />
        </TabsContent>
        <TabsContent value="analytics" className="space-y-4">
          <div className="grid gap-4 md:grid-cols-2">
            <Card>
              <CardHeader>
                <CardTitle>Income by Category</CardTitle>
                <CardDescription>Your income sources breakdown</CardDescription>
              </CardHeader>
              <CardContent className="pl-2">
                <IncomeChart transactions={transactions} />
              </CardContent>
            </Card>
            <Card>
              <CardHeader>
                <CardTitle>Expenses by Category</CardTitle>
                <CardDescription>Where your money is going</CardDescription>
              </CardHeader>
              <CardContent className="pl-2">
                <ExpenseChart transactions={transactions} />
              </CardContent>
            </Card>
          </div>
        </TabsContent>
        <TabsContent value="budgets" className="space-y-4">
          <BudgetSection userId={user.id} transactions={transactions} />
        </TabsContent>
      </Tabs>

      <AddTransactionDialog
        open={isAddTransactionOpen}
        onOpenChange={setIsAddTransactionOpen}
        onAddTransaction={handleAddTransaction}
      />
    </DashboardLayout>
  )
}
