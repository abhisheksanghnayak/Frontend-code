"use client"

import { useEffect } from "react"
import { useRouter } from "next/navigation"

export default function DemoPage() {
  const router = useRouter()

  useEffect(() => {
    // Create a demo user if it doesn't exist
    const users = JSON.parse(localStorage.getItem("users") || "[]")
    let demoUser = users.find((u) => u.email === "demo@example.com")

    if (!demoUser) {
      demoUser = {
        id: "demo-user",
        name: "Demo User",
        email: "demo@example.com",
        password: "demo123",
      }
      users.push(demoUser)
      localStorage.setItem("users", JSON.stringify(users))
    }

    // Set as current user
    localStorage.setItem("currentUser", JSON.stringify(demoUser))

    // Initialize demo data if it doesn't exist
    if (!localStorage.getItem(`transactions_${demoUser.id}`)) {
      const demoTransactions = [
        {
          id: "t1",
          amount: 3000,
          type: "income",
          category: "Salary",
          description: "Monthly salary",
          date: new Date(Date.now() - 15 * 24 * 60 * 60 * 1000).toISOString(),
        },
        {
          id: "t2",
          amount: 500,
          type: "expense",
          category: "Rent",
          description: "Monthly rent",
          date: new Date(Date.now() - 10 * 24 * 60 * 60 * 1000).toISOString(),
        },
        {
          id: "t3",
          amount: 120,
          type: "expense",
          category: "Groceries",
          description: "Weekly groceries",
          date: new Date(Date.now() - 7 * 24 * 60 * 60 * 1000).toISOString(),
        },
        {
          id: "t4",
          amount: 50,
          type: "expense",
          category: "Entertainment",
          description: "Movie tickets",
          date: new Date(Date.now() - 3 * 24 * 60 * 60 * 1000).toISOString(),
        },
        {
          id: "t5",
          amount: 200,
          type: "income",
          category: "Freelance",
          description: "Logo design project",
          date: new Date(Date.now() - 2 * 24 * 60 * 60 * 1000).toISOString(),
        },
      ]
      localStorage.setItem(`transactions_${demoUser.id}`, JSON.stringify(demoTransactions))

      // Set demo budgets
      const demoBudgets = [
        { id: "b1", category: "Groceries", amount: 400, period: "monthly" },
        { id: "b2", category: "Entertainment", amount: 200, period: "monthly" },
        { id: "b3", category: "Rent", amount: 1000, period: "monthly" },
      ]
      localStorage.setItem(`budgets_${demoUser.id}`, JSON.stringify(demoBudgets))
    }

    // Redirect to dashboard
    router.push("/dashboard")
  }, [router])

  return <div className="flex items-center justify-center min-h-screen">Loading demo account...</div>
}
