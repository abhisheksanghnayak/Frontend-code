"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import Link from "next/link"
import { useRouter } from "next/navigation"
import { MoneyIcon } from "@/components/icons"

export default function LoginPage() {
  const [formData, setFormData] = useState({
    email: "",
    password: "",
  })
  const [error, setError] = useState("")
  const router = useRouter()

  const handleChange = (e) => {
    const { name, value } = e.target
    setFormData((prev) => ({ ...prev, [name]: value }))
  }

  const handleSubmit = (e) => {
    e.preventDefault()
    setError("")

    // Basic validation
    if (!formData.email || !formData.password) {
      setError("All fields are required")
      return
    }

    // In a real app, you would send this data to your backend
    // For now, we'll simulate login by checking localStorage
    const users = JSON.parse(localStorage.getItem("users") || "[]")
    const user = users.find((u) => u.email === formData.email && u.password === formData.password)

    if (!user) {
      setError("Invalid email or password")
      return
    }

    // Store the current user
    localStorage.setItem("currentUser", JSON.stringify(user))

    // Redirect to dashboard
    router.push("/dashboard")
  }

  const handleDemoLogin = () => {
    // Create a demo user if it doesn't exist
    const users = JSON.parse(localStorage.getItem("users") || "[]")
    let demoUser = users.find((u) => u.email === "demo@example.com")

    if (!demoUser) {
      demoUser = {
        id: "demo-user",
        name: "Demo User",
        email: "demo@example.com",
        password: "demo123",
      }
      users.push(demoUser)
      localStorage.setItem("users", JSON.stringify(users))
    }

    // Set as current user
    localStorage.setItem("currentUser", JSON.stringify(demoUser))

    // Initialize demo data if it doesn't exist
    if (!localStorage.getItem(`transactions_${demoUser.id}`)) {
      const demoTransactions = [
        {
          id: "t1",
          amount: 3000,
          type: "income",
          category: "Salary",
          description: "Monthly salary",
          date: new Date(Date.now() - 15 * 24 * 60 * 60 * 1000).toISOString(),
        },
        {
          id: "t2",
          amount: 500,
          type: "expense",
          category: "Rent",
          description: "Monthly rent",
          date: new Date(Date.now() - 10 * 24 * 60 * 60 * 1000).toISOString(),
        },
        {
          id: "t3",
          amount: 120,
          type: "expense",
          category: "Groceries",
          description: "Weekly groceries",
          date: new Date(Date.now() - 7 * 24 * 60 * 60 * 1000).toISOString(),
        },
        {
          id: "t4",
          amount: 50,
          type: "expense",
          category: "Entertainment",
          description: "Movie tickets",
          date: new Date(Date.now() - 3 * 24 * 60 * 60 * 1000).toISOString(),
        },
        {
          id: "t5",
          amount: 200,
          type: "income",
          category: "Freelance",
          description: "Logo design project",
          date: new Date(Date.now() - 2 * 24 * 60 * 60 * 1000).toISOString(),
        },
      ]
      localStorage.setItem(`transactions_${demoUser.id}`, JSON.stringify(demoTransactions))

      // Set demo budgets
      const demoBudgets = [
        { id: "b1", category: "Groceries", amount: 400, period: "monthly" },
        { id: "b2", category: "Entertainment", amount: 200, period: "monthly" },
        { id: "b3", category: "Rent", amount: 1000, period: "monthly" },
      ]
      localStorage.setItem(`budgets_${demoUser.id}`, JSON.stringify(demoBudgets))
    }

    // Redirect to dashboard
    router.push("/dashboard")
  }

  return (
    <div className="flex min-h-screen items-center justify-center bg-gray-50 px-4 py-12 dark:bg-gray-900">
      <Card className="w-full max-w-md">
        <CardHeader className="space-y-1">
          <div className="flex items-center justify-center mb-6">
            <Link href="/" className="flex items-center">
              <MoneyIcon className="h-6 w-6 text-green-600" />
              <span className="ml-2 text-2xl font-bold">FinTrack</span>
            </Link>
          </div>
          <CardTitle className="text-2xl font-bold">Sign in</CardTitle>
          <CardDescription>Enter your email and password to sign in to your account</CardDescription>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleSubmit} className="space-y-4">
            {error && <div className="text-sm font-medium text-red-500">{error}</div>}
            <div className="space-y-2">
              <Label htmlFor="email">Email</Label>
              <Input
                id="email"
                name="email"
                type="email"
                placeholder="john@example.com"
                value={formData.email}
                onChange={handleChange}
                required
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="password">Password</Label>
              <Input
                id="password"
                name="password"
                type="password"
                value={formData.password}
                onChange={handleChange}
                required
              />
            </div>
            <Button type="submit" className="w-full bg-green-600 hover:bg-green-700">
              Sign in
            </Button>
          </form>
          <div className="mt-4">
            <Button variant="outline" className="w-full" onClick={handleDemoLogin}>
              Try Demo Account
            </Button>
          </div>
        </CardContent>
        <CardFooter>
          <div className="text-sm text-gray-500 dark:text-gray-400">
            Don&apos;t have an account?{" "}
            <Link href="/register" className="text-green-600 hover:underline">
              Sign up
            </Link>
          </div>
        </CardFooter>
      </Card>
    </div>
  )
}
