"use client"

import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip"
import { ResponsiveContainer, PieChart as RechartsPieChart, Pie as RechartsPie, Cell as RechartsCell } from "recharts"

export function ChartContainer({ className, children }) {
  return <div className={`rounded-md border ${className}`}>{children}</div>
}

export const PieChart = ({ children }) => {
  return (
    <ResponsiveContainer width="100%" height={300}>
      <RechartsPieChart>{children}</RechartsPieChart>
    </ResponsiveContainer>
  )
}

export const Pie = RechartsPie
export const Cell = RechartsCell

export const ChartTooltipContent = ({ content }) => {
  return (
    <TooltipProvider>
      <Tooltip>
        <TooltipTrigger asChild>{content}</TooltipTrigger>
        <TooltipContent className="bg-popover text-popover-foreground border-popover-foreground data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0 data-[state=closed]:zoom-out-95 data-[state=open]:zoom-in-95 data-[state=closed]:slide-out-to-top-0 data-[state=open]:slide-in-from-top-0">
          Tooltip
        </TooltipContent>
      </Tooltip>
    </TooltipProvider>
  )
}

export const ChartTooltip = ({ children }) => {
  return (
    <TooltipProvider>
      <Tooltip>
        <TooltipTrigger asChild>{children}</TooltipTrigger>
        <TooltipContent className="bg-popover text-popover-foreground border-popover-foreground data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0 data-[state=closed]:zoom-out-95 data-[state=open]:zoom-in-95 data-[state=closed]:slide-out-to-top-0 data-[state=open]:slide-in-from-top-0">
          Tooltip
        </TooltipContent>
      </Tooltip>
    </TooltipProvider>
  )
}
