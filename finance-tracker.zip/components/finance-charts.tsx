"use client"

import { useMemo } from "react"
import { ChartContainer, ChartTooltip, ChartTooltipContent, PieChart, Pie, Cell } from "@/components/ui/chart"

// Chart colors
const COLORS = [
  "#0088FE",
  "#00C49F",
  "#FFBB28",
  "#FF8042",
  "#8884D8",
  "#82CA9D",
  "#FF6B6B",
  "#6A7FDB",
  "#61DAFB",
  "#F28482",
]

export function ExpenseChart({ transactions }) {
  const expenseData = useMemo(() => {
    // Filter expense transactions
    const expenses = transactions.filter((t) => t.type === "expense")

    // Group by category and sum amounts
    const categoryMap = {}
    expenses.forEach((t) => {
      if (!categoryMap[t.category]) {
        categoryMap[t.category] = 0
      }
      categoryMap[t.category] += t.amount
    })

    // Convert to array format for chart
    return Object.entries(categoryMap).map(([name, value]) => ({
      name,
      value,
    }))
  }, [transactions])

  if (expenseData.length === 0) {
    return (
      <div className="flex items-center justify-center h-[300px] text-muted-foreground">No expense data to display</div>
    )
  }

  return (
    <ChartContainer className="h-[300px]">
      <PieChart>
        <Pie
          data={expenseData}
          dataKey="value"
          nameKey="name"
          cx="50%"
          cy="50%"
          outerRadius={80}
          fill="#8884d8"
          label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
        >
          {expenseData.map((entry, index) => (
            <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
          ))}
        </Pie>
        <ChartTooltip>
          <ChartTooltipContent
            content={({ payload }) => {
              if (payload && payload.length) {
                return (
                  <div className="p-2">
                    <p className="font-medium">{payload[0].name}</p>
                    <p className="text-sm">${payload[0].value.toFixed(2)}</p>
                  </div>
                )
              }
              return null
            }}
          />
        </ChartTooltip>
      </PieChart>
    </ChartContainer>
  )
}

export function IncomeChart({ transactions }) {
  const incomeData = useMemo(() => {
    // Filter income transactions
    const incomes = transactions.filter((t) => t.type === "income")

    // Group by category and sum amounts
    const categoryMap = {}
    incomes.forEach((t) => {
      if (!categoryMap[t.category]) {
        categoryMap[t.category] = 0
      }
      categoryMap[t.category] += t.amount
    })

    // Convert to array format for chart
    return Object.entries(categoryMap).map(([name, value]) => ({
      name,
      value,
    }))
  }, [transactions])

  if (incomeData.length === 0) {
    return (
      <div className="flex items-center justify-center h-[300px] text-muted-foreground">No income data to display</div>
    )
  }

  return (
    <ChartContainer className="h-[300px]">
      <PieChart>
        <Pie
          data={incomeData}
          dataKey="value"
          nameKey="name"
          cx="50%"
          cy="50%"
          outerRadius={80}
          fill="#8884d8"
          label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
        >
          {incomeData.map((entry, index) => (
            <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
          ))}
        </Pie>
        <ChartTooltip>
          <ChartTooltipContent
            content={({ payload }) => {
              if (payload && payload.length) {
                return (
                  <div className="p-2">
                    <p className="font-medium">{payload[0].name}</p>
                    <p className="text-sm">${payload[0].value.toFixed(2)}</p>
                  </div>
                )
              }
              return null
            }}
          />
        </ChartTooltip>
      </PieChart>
    </ChartContainer>
  )
}
