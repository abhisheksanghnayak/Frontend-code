"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Progress } from "@/components/ui/progress"
import { PlusIcon, Trash2Icon } from "lucide-react"

const DEFAULT_CATEGORIES = [
  "Food",
  "Rent",
  "Transportation",
  "Entertainment",
  "Utilities",
  "Shopping",
  "Healthcare",
  "Education",
  "Other",
]

export default function BudgetSection({ userId, transactions }) {
  const [budgets, setBudgets] = useState([])
  const [newBudget, setNewBudget] = useState({
    category: "",
    amount: "",
    period: "monthly",
  })
  const [error, setError] = useState("")

  useEffect(() => {
    // Load budgets from localStorage
    const savedBudgets = JSON.parse(localStorage.getItem(`budgets_${userId}`) || "[]")
    setBudgets(savedBudgets)
  }, [userId])

  const handleChange = (field, value) => {
    setNewBudget((prev) => ({
      ...prev,
      [field]: value,
    }))
    setError("")
  }

  const handleAddBudget = () => {
    setError("")

    // Validation
    if (!newBudget.category) {
      setError("Please select a category")
      return
    }

    if (!newBudget.amount || isNaN(Number(newBudget.amount)) || Number(newBudget.amount) <= 0) {
      setError("Please enter a valid amount")
      return
    }

    // Check if budget for this category already exists
    if (budgets.some((b) => b.category === newBudget.category)) {
      setError("Budget for this category already exists")
      return
    }

    // Add new budget
    const updatedBudgets = [
      ...budgets,
      {
        id: Date.now().toString(),
        category: newBudget.category,
        amount: Number(newBudget.amount),
        period: newBudget.period,
      },
    ]

    setBudgets(updatedBudgets)
    localStorage.setItem(`budgets_${userId}`, JSON.stringify(updatedBudgets))

    // Reset form
    setNewBudget({
      category: "",
      amount: "",
      period: "monthly",
    })
  }

  const handleDeleteBudget = (id) => {
    const updatedBudgets = budgets.filter((budget) => budget.id !== id)
    setBudgets(updatedBudgets)
    localStorage.setItem(`budgets_${userId}`, JSON.stringify(updatedBudgets))
  }

  // Calculate spending for each budget
  const budgetsWithSpending = budgets.map((budget) => {
    // Filter transactions by category and type (expense)
    const categoryExpenses = transactions.filter((t) => t.category === budget.category && t.type === "expense")

    // Sum the amounts
    const spent = categoryExpenses.reduce((sum, t) => sum + t.amount, 0)

    // Calculate percentage
    const percentage = budget.amount > 0 ? Math.min(Math.round((spent / budget.amount) * 100), 100) : 0

    return {
      ...budget,
      spent,
      percentage,
    }
  })

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle>Budget Management</CardTitle>
          <CardDescription>Set and track your spending limits</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid gap-4 md:grid-cols-4">
            <div className="md:col-span-1">
              <Label htmlFor="category">Category</Label>
              <Select value={newBudget.category} onValueChange={(value) => handleChange("category", value)}>
                <SelectTrigger id="category">
                  <SelectValue placeholder="Select category" />
                </SelectTrigger>
                <SelectContent>
                  {DEFAULT_CATEGORIES.map((category) => (
                    <SelectItem key={category} value={category}>
                      {category}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="md:col-span-1">
              <Label htmlFor="amount">Budget Amount</Label>
              <div className="flex items-center">
                <span className="mr-2">$</span>
                <Input
                  id="amount"
                  type="number"
                  step="0.01"
                  min="0.01"
                  value={newBudget.amount}
                  onChange={(e) => handleChange("amount", e.target.value)}
                  placeholder="0.00"
                />
              </div>
            </div>
            <div className="md:col-span-1">
              <Label htmlFor="period">Period</Label>
              <Select value={newBudget.period} onValueChange={(value) => handleChange("period", value)}>
                <SelectTrigger id="period">
                  <SelectValue placeholder="Select period" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="monthly">Monthly</SelectItem>
                  <SelectItem value="weekly">Weekly</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="md:col-span-1 flex items-end">
              <Button onClick={handleAddBudget} className="w-full bg-green-600 hover:bg-green-700">
                <PlusIcon className="mr-2 h-4 w-4" /> Add Budget
              </Button>
            </div>
          </div>
          {error && <div className="text-sm font-medium text-red-500 mt-2">{error}</div>}
        </CardContent>
      </Card>

      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
        {budgetsWithSpending.map((budget) => (
          <Card key={budget.id}>
            <CardHeader className="pb-2">
              <div className="flex items-center justify-between">
                <CardTitle className="text-lg">{budget.category}</CardTitle>
                <Button
                  variant="ghost"
                  size="icon"
                  onClick={() => handleDeleteBudget(budget.id)}
                  className="h-8 w-8 text-muted-foreground hover:text-red-500"
                >
                  <Trash2Icon className="h-4 w-4" />
                </Button>
              </div>
              <CardDescription>{budget.period === "monthly" ? "Monthly" : "Weekly"} budget</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-2">
                <div className="flex items-center justify-between text-sm">
                  <span>
                    ${budget.spent.toFixed(2)} of ${budget.amount.toFixed(2)}
                  </span>
                  <span className={budget.percentage >= 100 ? "text-red-500 font-medium" : ""}>
                    {budget.percentage}%
                  </span>
                </div>
                <Progress
                  value={budget.percentage}
                  className={budget.percentage >= 100 ? "bg-red-200" : ""}
                  indicatorClassName={budget.percentage >= 100 ? "bg-red-500" : ""}
                />
                <div className="text-xs text-muted-foreground">
                  {budget.percentage >= 100
                    ? "Budget exceeded!"
                    : `$${(budget.amount - budget.spent).toFixed(2)} remaining`}
                </div>
              </div>
            </CardContent>
          </Card>
        ))}

        {budgetsWithSpending.length === 0 && (
          <div className="md:col-span-2 lg:col-span-3 text-center py-8 text-muted-foreground">
            No budgets set. Add your first budget to start tracking your spending.
          </div>
        )}
      </div>
    </div>
  )
}
