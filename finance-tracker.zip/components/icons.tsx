import {
  ArrowDown,
  ArrowUp,
  BarChart3,
  Calendar,
  CreditCard,
  DollarSign,
  Filter,
  Home,
  Lock,
  LogOut,
  Menu,
  DollarSignIcon as Money,
  PieChart,
  Plus,
  Search,
  Settings,
  Target,
  TrendingUp,
  Trash2,
  User,
  Wallet,
  X,
} from "lucide-react"

// Re-export icons
export const ArrowDownIcon = ArrowDown
export const ArrowUpIcon = ArrowUp
export const BarChart3Icon = BarChart3
export const CalendarIcon = Calendar
export const CreditCardIcon = CreditCard
export const DollarSignIcon = DollarSign
export const FilterIcon = Filter
export const HomeIcon = Home
export const LockIcon = Lock
export const LogOutIcon = LogOut
export const MenuIcon = Menu
export const MoneyIcon = Money
export const PieChartIcon = PieChart
export const PlusIcon = Plus
export const SearchIcon = Search
export const SettingsIcon = Settings
export const TargetIcon = Target
export const TrendingUpIcon = TrendingUp
export const Trash2Icon = Trash2
export const UserIcon = User
export const WalletIcon = Wallet
export const XIcon = X
